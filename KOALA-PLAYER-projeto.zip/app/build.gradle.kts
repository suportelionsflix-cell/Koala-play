plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.koala.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.koala.player"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // LibVLC inclui todas as arquiteturas por padrão. Estas duas cobrem celulares e TVs atuais e reduzem o APK.
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        // As classes do Media3 são marcadas como instáveis; isso não impede o uso.
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")

    // ExoPlayer (AndroidX Media3)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")

    // VLC (LibVLC)
    implementation("org.videolan.android:libvlc-all:3.6.0")

    // Proxy interno para as chamadas da API do servidor IPTV
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}