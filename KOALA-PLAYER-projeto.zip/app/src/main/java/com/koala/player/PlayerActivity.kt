package com.koala.player

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Reproduz o vídeo dentro do app, com ExoPlayer (AndroidX Media3) ou LibVLC.
 * O botão no topo troca de player mantendo o ponto atual.
 */
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_VOD = "vod"
        const val EXTRA_ENGINE = "engine"
        const val EXTRA_POS = "pos"
        const val EXTRA_ENDED = "ended"
        private const val UA = "Mozilla/5.0 (Linux; Android) KoalaPlayer"
        private const val SEEK_MS = 10_000L
    }

    private lateinit var root: FrameLayout
    private lateinit var swapBtn: Button
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView

    private lateinit var url: String
    private var vod = false
    private var engine = "exo"
    private var ended = false

    private var exo: ExoPlayer? = null
    private var exoView: PlayerView? = null

    private var libVlc: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private var vlcLayout: VLCVideoLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        url = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }
        vod = intent.getBooleanExtra(EXTRA_VOD, false)
        engine = if (intent.getStringExtra(EXTRA_ENGINE) == "vlc") "vlc" else "exo"
        val title = intent.getStringExtra(EXTRA_TITLE) ?: ""
        val startPos = intent.getLongExtra(EXTRA_POS, 0L)

        buildUi(title)
        start(startPos)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = closePlayer()
        })
    }

    // ---------- interface ----------

    private fun buildUi(title: String) {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val back = Button(this).apply {
            text = "‹ Voltar"
            setOnClickListener { closePlayer() }
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(16), 0, dp(16), 0)
        }
        swapBtn = Button(this).apply { setOnClickListener { swapEngine() } }
        bar.addView(back)
        bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(swapBtn)
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        errorText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
        }
        val retry = Button(this).apply {
            text = "Tentar de novo"
            setOnClickListener { start(currentPos()) }
        }
        val other = Button(this).apply {
            text = "Tentar com o outro player"
            setOnClickListener { swapEngine() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(retry)
            addView(other)
        }
        errorBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xCC000000.toInt())
            setPadding(dp(24), dp(24), dp(24), dp(24))
            visibility = View.GONE
            addView(errorText)
            addView(row)
        }
        root.addView(errorBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showError(msg: String) = runOnUiThread {
        errorText.text = msg
        errorBox.visibility = View.VISIBLE
        errorBox.getChildAt(1).requestFocus()
    }

    private fun hideError() { errorBox.visibility = View.GONE }

    // ---------- controle dos players ----------

    private fun start(pos: Long) {
        releasePlayers()
        hideError()
        swapBtn.text = if (engine == "vlc") "Trocar para ExoPlayer" else "Trocar para VLC"
        try {
            if (engine == "vlc") startVlc(pos) else startExo(pos)
        } catch (e: Throwable) {
            showError("Não foi possível iniciar o ${if (engine == "vlc") "VLC" else "ExoPlayer"}.")
        }
    }

    private fun swapEngine() {
        val pos = currentPos()
        engine = if (engine == "vlc") "exo" else "vlc"
        start(pos)
    }

    private fun startExo(pos: Long) {
        val dataSource = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(UA)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(dataSource))
            .build()
        val view = PlayerView(this).apply {
            this.player = player
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        root.addView(view, 0)
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition()
                    player.prepare()
                } else {
                    showError("Não foi possível reproduzir (ExoPlayer: ${error.errorCodeName}).")
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) ended = true
            }
        })
        player.setMediaItem(MediaItem.fromUri(url))
        if (vod && pos > 0) player.seekTo(pos)
        player.prepare()
        player.playWhenReady = true
        exo = player
        exoView = view
    }

    private fun startVlc(pos: Long) {
        val args = arrayListOf("--network-caching=2000", "--http-reconnect", "--no-drop-late-frames", "--no-skip-frames")
        val lib = LibVLC(this, args)
        val mp = MediaPlayer(lib)
        val layout = VLCVideoLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            isFocusable = false
        }
        root.addView(layout, 0)
        mp.attachViews(layout, null, false, false)
        var seeked = false
        mp.setEventListener { ev ->
            when (ev.type) {
                MediaPlayer.Event.EncounteredError -> showError("Não foi possível reproduzir (VLC).")
                MediaPlayer.Event.EndReached -> ended = true
                MediaPlayer.Event.Playing -> if (!seeked) {
                    seeked = true
                    if (vod && pos > 0) mp.time = pos
                }
            }
        }
        val media = Media(lib, Uri.parse(url)).apply {
            setHWDecoderEnabled(true, false)
            addOption(":network-caching=2000")
        }
        mp.media = media
        media.release()
        mp.play()
        libVlc = lib
        vlc = mp
        vlcLayout = layout
        layout.setOnClickListener { togglePlay() }
    }

    private fun togglePlay() {
        val mp = vlc
        if (mp != null) { if (mp.isPlaying) mp.pause() else mp.play(); return }
        exo?.let { it.playWhenReady = !it.playWhenReady }
    }

    private fun currentPos(): Long = if (engine == "vlc") (vlc?.time ?: 0L) else (exo?.currentPosition ?: 0L)

    private fun releasePlayers() {
        exoView?.let { root.removeView(it) }
        exoView = null
        exo?.release()
        exo = null

        vlc?.let {
            try { it.setEventListener(null); it.stop(); it.detachViews(); it.release() } catch (_: Throwable) {}
        }
        vlc = null
        libVlc?.let { try { it.release() } catch (_: Throwable) {} }
        libVlc = null
        vlcLayout?.let { root.removeView(it) }
        vlcLayout = null
    }

    private fun closePlayer() {
        val data = Intent()
            .putExtra(EXTRA_URL, url)
            .putExtra(EXTRA_POS, currentPos())
            .putExtra(EXTRA_ENGINE, engine)
            .putExtra(EXTRA_VOD, vod)
            .putExtra(EXTRA_ENDED, ended)
        setResult(RESULT_OK, data)
        finish()
    }

    // ---------- controle remoto ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && errorBox.visibility != View.VISIBLE) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    togglePlay(); return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                    if (engine == "vlc" && currentFocus !is Button) { togglePlay(); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ->
                    if (vod && engine == "vlc") { vlc?.let { it.time = it.time + SEEK_MS }; return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND ->
                    if (vod && engine == "vlc") { vlc?.let { it.time = maxOf(0L, it.time - SEEK_MS) }; return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------- ciclo de vida ----------

    override fun onStop() {
        super.onStop()
        exo?.playWhenReady = false
        vlc?.pause()
    }

    override fun onStart() {
        super.onStart()
        exo?.playWhenReady = true
        if (vlc != null) vlc?.play()
    }

    override fun onDestroy() {
        releasePlayers()
        super.onDestroy()
    }
}