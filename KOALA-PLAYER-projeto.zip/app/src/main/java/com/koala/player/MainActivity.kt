package com.koala.player

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit

/**
 * Hospeda a interface do KOALA PLAYER (assets/index.html) e entrega a reprodução
 * de vídeo para o PlayerActivity (ExoPlayer ou LibVLC).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val host = "appassets.androidplatform.net"
    private val proxyPrefix = "https://$host/proxy?url="

    private val http = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val indexHtml: String by lazy {
        assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            .replace("name=\"sintonia-proxy\" content=\"\"", "name=\"sintonia-proxy\" content=\"$proxyPrefix\"")
    }

    private val playLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data ?: return@registerForActivityResult
        val json = JSONObject()
            .put("url", d.getStringExtra(PlayerActivity.EXTRA_URL) ?: "")
            .put("pos", d.getLongExtra(PlayerActivity.EXTRA_POS, 0L) / 1000)
            .put("engine", d.getStringExtra(PlayerActivity.EXTRA_ENGINE) ?: "exo")
            .put("vod", d.getBooleanExtra(PlayerActivity.EXTRA_VOD, false))
            .put("ended", d.getBooleanExtra(PlayerActivity.EXTRA_ENDED, false))
        web.evaluateJavascript(
            "window.onNativeDone&&window.onNativeDone(${JSONObject.quote(json.toString())})", null
        )
    }

    /** Ponte chamada pelo JavaScript: KoalaNative.play(json). */
    inner class Bridge {
        @JavascriptInterface
        fun play(json: String) {
            runOnUiThread {
                val o = JSONObject(json)
                val i = Intent(this@MainActivity, PlayerActivity::class.java)
                    .putExtra(PlayerActivity.EXTRA_URL, o.getString("url"))
                    .putExtra(PlayerActivity.EXTRA_TITLE, o.optString("title"))
                    .putExtra(PlayerActivity.EXTRA_VOD, o.optBoolean("vod"))
                    .putExtra(PlayerActivity.EXTRA_ENGINE, o.optString("engine", "exo"))
                    .putExtra(PlayerActivity.EXTRA_POS, o.optLong("pos", 0L) * 1000)
                playLauncher.launch(i)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        web = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            addJavascriptInterface(Bridge(), "KoalaNative")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val u = request.url
                    if (u.host != host) return null
                    return when (u.path) {
                        "/", "/index.html" -> WebResourceResponse(
                            "text/html", "utf-8", ByteArrayInputStream(indexHtml.toByteArray(Charsets.UTF_8))
                        )
                        "/proxy" -> proxy(u.getQueryParameter("url"))
                        else -> notFound()
                    }
                }
            }
            isFocusable = true
            isFocusableInTouchMode = true
        }
        setContentView(web)
        web.loadUrl("https://$host/index.html")
        web.requestFocus()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.onNativeBack&&window.onNativeBack()") { r ->
                    if (r != "true") finish()
                }
            }
        })
    }

    /** Repassa chamadas da API e imagens do servidor IPTV, sem as limitações de CORS do navegador. */
    private fun proxy(target: String?): WebResourceResponse {
        if (target.isNullOrBlank()) return notFound()
        return try {
            val req = Request.Builder().url(target)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android) KoalaPlayer")
                .build()
            val resp = http.newCall(req).execute()
            val ct = resp.header("Content-Type") ?: "application/octet-stream"
            val mime = ct.substringBefore(';').trim()
            val enc = if (ct.contains("charset=", true)) ct.substringAfter("charset=").trim() else null
            val headers = mutableMapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to if (mime.startsWith("image/")) "max-age=86400" else "no-cache"
            )
            WebResourceResponse(
                mime, enc, resp.code, resp.message.ifBlank { "OK" }, headers,
                resp.body?.byteStream() ?: ByteArrayInputStream(ByteArray(0))
            )
        } catch (e: Exception) {
            WebResourceResponse(
                "text/plain", "utf-8", 502, "Bad Gateway",
                mapOf("Access-Control-Allow-Origin" to "*"),
                ByteArrayInputStream("Falha ao acessar o servidor: ${e.message}".toByteArray())
            )
        }
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onDestroy() {
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}